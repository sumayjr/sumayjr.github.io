"""Headless tests for DentoFacLib shared infrastructure."""

import sys
import tempfile
import types
from pathlib import Path
from unittest import mock

from DentoFacLib.Diagnostics import DiagnosticsCollector, tail_logs
from DentoFacLib.Models import (
    DENTAL_SEGMENTATOR_MODEL, ModelStore, ValidationResult, ValidationStatus,
    find_configuration_folder, validate_model,
)
from DentoFacLib.Dependencies import DependencyStatus, NNUNetDependencyService
from DentoFacLib.ExtensionStatus import (
    EXPECTED_EXTENSIONS, CollectedExtensions, ExpectedExtension,
    collect_installed_extension_revisions, evaluate_required_extensions,
    format_extension_status_row,
)


def _collected(revisions, manager_available=True):
    return CollectedExtensions(manager_available, revisions)


def _valid_model_tree(root: Path) -> None:
    config = root / "Dataset111_Test" / "nnUNetTrainer__nnUNetPlans__3d_fullres"
    (config / "fold_0").mkdir(parents=True)
    (config / "dataset.json").write_text("{}", encoding="utf-8")
    (config / "plans.json").write_text("{}", encoding="utf-8")
    (config / "fold_0" / "checkpoint_final.pth").write_bytes(b"test")


def test_model_store_uses_private_versioned_cache_and_confirmed_copy():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        legacy = root / "legacy"
        _valid_model_tree(legacy)
        store = ModelStore(DENTAL_SEGMENTATOR_MODEL, root / "app-data")

        assert "DentoFac/models" in str(store.model_root)
        authoritative = lambda path: ValidationResult(True, "", True, path, ValidationStatus.VALID)
        assert store.copy_validated_legacy(legacy, lambda source, target: source == legacy, authoritative)
        assert legacy.exists()  # coexistence: a legacy source is never changed
        assert validate_model(store.model_root).isValid
        assert store.metadata_path().exists()


def test_model_store_never_copies_without_confirmation_or_when_destination_exists():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        legacy = root / "legacy"
        _valid_model_tree(legacy)
        store = ModelStore(DENTAL_SEGMENTATOR_MODEL, root / "app-data")
        authoritative = lambda path: ValidationResult(True, "", True, path, ValidationStatus.VALID)
        assert not store.copy_validated_legacy(legacy, lambda *_: False, authoritative)
        assert not store.model_root.exists()


def test_model_validation_uses_the_public_configuration_lookup():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        _valid_model_tree(root)
        configuration = find_configuration_folder(root)

        class Parameter:
            # This deliberately conflicts with the model layout.  The private
            # upstream implementation detail must not influence our result.
            _configurationFolder = root / "incorrect-private-path"

            @staticmethod
            def isValid():
                return True, ""

        with mock.patch.dict(sys.modules, {"SlicerNNUNetLib": types.ModuleType("SlicerNNUNetLib")}):
            result = validate_model(root, parameter=Parameter())
        assert result.configurationFolder == configuration


def test_shared_diagnostics_is_bounded_and_provider_failures_are_contained():
    assert tail_logs(["a" * 10] * 4, max_lines=4, max_bytes=20) == ["a" * 10, "a" * 10]
    data = DiagnosticsCollector(lambda: {"workflow": "segmentator"}).collect()
    assert data["workflow"]["workflow"] == "segmentator"
    failed = DiagnosticsCollector(lambda: (_ for _ in ()).throw(RuntimeError())).collect()
    assert "collection_error" in failed["workflow"]


def test_hub_readiness_propagates_dependency_and_model_state():
    from DentoFacLib.Models import ValidationResult, ValidationStatus
    from DentoFacLib import RuntimeStatus

    with mock.patch.object(
        RuntimeStatus.NNUNetDependencyService, "status",
        return_value=DependencyStatus(True, False),
    ), mock.patch.object(
        RuntimeStatus, "validate_model",
        return_value=ValidationResult(False, "missing", True, None, ValidationStatus.MISSING),
    ):
        readiness = RuntimeStatus.collect_segmentator_readiness(_collected({"NNUNet": "unknown"}))
    assert not readiness.dependency_ready
    assert not readiness.model_ready
    assert "Python requirements" in readiness.summary


def test_readiness_distinguishes_missing_unloadable_and_manager_unavailable_nnunet():
    from DentoFacLib import RuntimeStatus

    valid_model = ValidationResult(True, "", True, Path("model"), ValidationStatus.VALID)
    with mock.patch.object(RuntimeStatus, "validate_model", return_value=valid_model):
        with mock.patch.object(
            RuntimeStatus.NNUNetDependencyService, "status", return_value=DependencyStatus(False, False),
        ):
            missing = RuntimeStatus.collect_segmentator_readiness(_collected({"NNUNet": None}))
            unloadable = RuntimeStatus.collect_segmentator_readiness(_collected({"NNUNet": "any-sha"}))
            manager_unavailable = RuntimeStatus.collect_segmentator_readiness(
                _collected({"NNUNet": None}, manager_available=False),
            )

    assert missing.summary == "NNUNet extension is not installed."
    assert "installed but could not be loaded" in unloadable.summary
    assert "Restart Slicer" in unloadable.summary
    assert "Extensions Manager is unavailable" in manager_unavailable.summary
    assert manager_unavailable.extension_installed is None


def test_readiness_reports_a_compatible_installed_nnunet():
    from DentoFacLib import RuntimeStatus

    valid_model = ValidationResult(True, "", True, Path("model"), ValidationStatus.VALID)
    with mock.patch.object(RuntimeStatus, "validate_model", return_value=valid_model), mock.patch.object(
        RuntimeStatus.NNUNetDependencyService, "status", return_value=DependencyStatus(True, True),
    ):
        readiness = RuntimeStatus.collect_segmentator_readiness(_collected({"NNUNet": "any-sha"}))
    assert readiness.dependency_ready
    assert readiness.summary == "DentoFac Segmentator is ready."


def test_readiness_reports_an_installed_nnunet_with_a_missing_required_api():
    from DentoFacLib import RuntimeStatus

    valid_model = ValidationResult(True, "", True, Path("model"), ValidationStatus.VALID)
    with mock.patch.object(RuntimeStatus, "validate_model", return_value=valid_model), mock.patch.object(
        RuntimeStatus.NNUNetDependencyService, "status", return_value=DependencyStatus(True, True, False),
    ):
        readiness = RuntimeStatus.collect_segmentator_readiness(_collected({"NNUNet": "any-sha"}))
    assert not readiness.dependency_ready
    assert "installed but could not be loaded" in readiness.summary


def test_capability_probe_inspects_the_full_contract_without_constructing_logic():
    class Parameter:
        @staticmethod
        def isValid():
            return True, ""

    class SegmentationLogic:
        def __init__(self):
            raise AssertionError("The capability probe must not construct SegmentationLogic")

        def setParameter(self):
            pass

        def startSegmentation(self):
            pass

        def loadSegmentation(self):
            pass

    nnunet_stub = types.ModuleType("SlicerNNUNetLib")
    nnunet_stub.Parameter = Parameter
    nnunet_stub.SegmentationLogic = SegmentationLogic
    with mock.patch.dict(sys.modules, {
        "SlicerNNUNetLib": nnunet_stub,
        "torch": types.ModuleType("torch"),
        "nnunetv2": types.ModuleType("nnunetv2"),
    }):
        status = NNUNetDependencyService().status()
    assert status.extension_importable
    assert status.extension_capable


def test_capability_probe_rejects_a_missing_segmentation_logic_method():
    class Parameter:
        @staticmethod
        def isValid():
            return True, ""

    class SegmentationLogic:
        def setParameter(self):
            pass

        def loadSegmentation(self):
            pass

    nnunet_stub = types.ModuleType("SlicerNNUNetLib")
    nnunet_stub.Parameter = Parameter
    nnunet_stub.SegmentationLogic = SegmentationLogic
    with mock.patch.dict(sys.modules, {"SlicerNNUNetLib": nnunet_stub}):
        status = NNUNetDependencyService().status()
    assert status.extension_importable
    assert not status.extension_capable


def test_model_validation_propagates_a_parameter_type_error():
    class Parameter:
        @staticmethod
        def isValid():
            raise TypeError("changed Parameter API")

    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        _valid_model_tree(root)
        with mock.patch.dict(sys.modules, {"SlicerNNUNetLib": types.ModuleType("SlicerNNUNetLib")}):
            try:
                validate_model(root, parameter=Parameter())
            except TypeError as error:
                assert str(error) == "changed Parameter API"
            else:
                raise AssertionError("Parameter TypeError must propagate")


def test_readiness_attributes_a_changed_parameter_api_to_nnunet_capability():
    from DentoFacLib import RuntimeStatus

    with mock.patch.object(
        RuntimeStatus.NNUNetDependencyService, "status", return_value=DependencyStatus(True, True),
    ), mock.patch.object(RuntimeStatus, "validate_model", side_effect=TypeError("changed Parameter API")):
        readiness = RuntimeStatus.collect_segmentator_readiness(_collected({"NNUNet": "any-sha"}))
    assert readiness.summary == (
        "NNUNet is installed but could not be loaded. Restart Slicer and check that the extension is enabled."
    )
    assert not readiness.dependency_ready
    assert not readiness.model_ready
    assert not readiness.model_authoritative


def test_readiness_does_not_reclassify_an_import_error_as_a_capability_failure():
    from DentoFacLib import RuntimeStatus

    with mock.patch.object(
        RuntimeStatus.NNUNetDependencyService, "status", return_value=DependencyStatus(True, True),
    ), mock.patch.object(RuntimeStatus, "validate_model", side_effect=ImportError("NNUNet missing")):
        try:
            RuntimeStatus.collect_segmentator_readiness(_collected({"NNUNet": "any-sha"}))
        except ImportError as error:
            assert str(error) == "NNUNet missing"
        else:
            raise AssertionError("ImportError must not be reclassified as a capability failure")


def test_required_extensions_all_present_at_accepted_revision():
    report = evaluate_required_extensions(
        [ExpectedExtension("NNUNet", "0cb736d", ("0cb736d",))],
        _collected({"NNUNet": "0cb736d"}),
    )
    assert report.all_ok
    assert report.rows[0].status == "present_ok"


def test_required_extensions_marks_a_missing_extension():
    report = evaluate_required_extensions(
        [ExpectedExtension("NNUNet", "0cb736d", ("0cb736d",))],
        _collected({"NNUNet": None}),
    )
    assert not report.all_ok
    assert report.rows[0].status == "missing"


def test_required_extensions_marks_an_unavailable_manager_distinctly():
    report = evaluate_required_extensions(
        [ExpectedExtension("NNUNet", "0cb736d", ("0cb736d",))],
        _collected({"NNUNet": None}, manager_available=False),
    )
    assert not report.all_ok
    assert report.rows[0].status == "manager_unavailable"


def test_required_extensions_marks_a_wrong_revision():
    report = evaluate_required_extensions(
        [ExpectedExtension("NNUNet", "0cb736d", ("0cb736d",))],
        _collected({"NNUNet": "different-sha"}),
    )
    assert not report.all_ok
    assert report.rows[0].status == "version_mismatch"


def test_required_extensions_supports_a_present_only_gate():
    report = evaluate_required_extensions(
        [ExpectedExtension("NNUNet", "site managed", (), require_accepted_revision=False)],
        _collected({"NNUNet": "any-revision"}),
    )
    assert report.all_ok
    assert report.rows[0].status == "present_ok"


def test_required_extensions_matches_a_full_detected_sha_to_a_short_accepted_sha():
    full_revision = "0cb736d" + "a" * 33
    report = evaluate_required_extensions(
        [ExpectedExtension("NNUNet", "0cb736d", ["0cb736d"])],
        _collected({"NNUNet": full_revision}),
    )
    assert report.all_ok
    assert report.rows[0].status == "present_ok"


def test_required_extensions_matches_a_short_detected_sha_to_a_full_accepted_sha():
    full_revision = "0cb736d" + "a" * 33
    report = evaluate_required_extensions(
        [ExpectedExtension("NNUNet", "0cb736d", [full_revision])],
        _collected({"NNUNet": "0cb736d"}),
    )
    assert report.all_ok
    assert report.rows[0].status == "present_ok"


def test_required_extensions_rejects_a_partial_prefix_collision():
    report = evaluate_required_extensions(
        [ExpectedExtension("NNUNet", "0cb736d", ["0cb736d"])],
        _collected({"NNUNet": "0cb999e"}),
    )
    assert not report.all_ok
    assert report.rows[0].status == "version_mismatch"


def test_required_extensions_matches_case_insensitively():
    report = evaluate_required_extensions(
        [ExpectedExtension("NNUNet", "0cb736d", ["0cb736d"])],
        _collected({"NNUNet": "0CB736D"}),
    )
    assert report.all_ok
    assert report.rows[0].status == "present_ok"


def test_required_extensions_keeps_unknown_and_missing_revisions_unhealthy():
    manifest = [ExpectedExtension("NNUNet", "0cb736d", ["0cb736d"])]
    unknown = evaluate_required_extensions(manifest, _collected({"NNUNet": "unknown"}))
    missing = evaluate_required_extensions(manifest, _collected({"NNUNet": None}))
    blank = evaluate_required_extensions(manifest, _collected({"NNUNet": "  "}))
    assert unknown.rows[0].status == "version_mismatch"
    assert missing.rows[0].status == "missing"
    assert blank.rows[0].status == "version_mismatch"


class _FakeExtensionsManager:
    """Mimics Slicer's extensionsManagerModel: metadata is keyed 'revision'."""

    def __init__(self, metadata):
        self._metadata = metadata

    def isExtensionInstalled(self, name):
        return name in self._metadata

    def extensionMetadata(self, name):
        return self._metadata.get(name, {})


def _with_fake_slicer(metadata):
    slicer_stub = types.ModuleType("slicer")
    slicer_stub.app = types.SimpleNamespace(
        extensionsManagerModel=lambda: _FakeExtensionsManager(metadata),
    )
    return mock.patch.dict(sys.modules, {"slicer": slicer_stub})


def test_collect_reads_the_revision_key_that_slicer_actually_exposes():
    # Slicer's extensionMetadata() returns the installed SHA under 'revision';
    # 'scmrevision' does not exist in that map.  Reading the wrong key made a
    # correctly installed NNUNet render red on a live runtime.
    manifest = [ExpectedExtension("NNUNet", "0cb736d", ["0cb736d"])]
    with _with_fake_slicer({"NNUNet": {"revision": "0cb736d"}}):
        detected = collect_installed_extension_revisions(manifest)
    assert detected == _collected({"NNUNet": "0cb736d"})
    assert evaluate_required_extensions(manifest, detected).all_ok


def test_collect_falls_back_to_scmrevision_when_present():
    manifest = [ExpectedExtension("NNUNet", "0cb736d", ["0cb736d"])]
    with _with_fake_slicer({"NNUNet": {"scmrevision": "0cb736d"}}):
        detected = collect_installed_extension_revisions(manifest)
    assert detected == _collected({"NNUNet": "0cb736d"})


def test_collect_reports_unknown_when_installed_without_a_revision():
    manifest = [ExpectedExtension("NNUNet", "0cb736d", ["0cb736d"])]
    with _with_fake_slicer({"NNUNet": {}}):
        detected = collect_installed_extension_revisions(manifest)
    assert detected == _collected({"NNUNet": "unknown"})
    assert evaluate_required_extensions(manifest, detected).rows[0].status == "version_mismatch"


def test_collect_reports_none_when_extension_is_not_installed():
    manifest = [ExpectedExtension("NNUNet", "0cb736d", ["0cb736d"])]
    with _with_fake_slicer({}):
        detected = collect_installed_extension_revisions(manifest)
    assert detected == _collected({"NNUNet": None})
    assert evaluate_required_extensions(manifest, detected).rows[0].status == "missing"


def test_collect_marks_a_missing_extensions_manager_as_unavailable():
    manifest = [ExpectedExtension("NNUNet", "0cb736d", ["0cb736d"])]
    slicer_stub = types.ModuleType("slicer")
    slicer_stub.app = types.SimpleNamespace(extensionsManagerModel=lambda: None)
    with mock.patch.dict(sys.modules, {"slicer": slicer_stub}):
        collected = collect_installed_extension_revisions(manifest)
    assert collected == _collected({"NNUNet": None}, manager_available=False)
    assert evaluate_required_extensions(manifest, collected).rows[0].status == "manager_unavailable"


def test_default_manifest_gates_nnunet_present_only():
    # The Hub ships NNUNet present-only: installed at any revision passes; only a
    # missing extension fails.  Exact-SHA pinning was removed as too fragile.
    nnunet = next(e for e in EXPECTED_EXTENSIONS if e.name == "NNUNet")
    assert nnunet.require_accepted_revision is False
    installed = evaluate_required_extensions(EXPECTED_EXTENSIONS, _collected({"NNUNet": "any-revision-at-all"}))
    assert installed.all_ok
    assert installed.rows[0].status == "present_ok"
    absent = evaluate_required_extensions(EXPECTED_EXTENSIONS, _collected({"NNUNet": None}))
    assert not absent.all_ok
    assert absent.rows[0].status == "missing"


def test_default_manifest_keeps_an_unknown_revision_installed_without_rendering_it():
    report = evaluate_required_extensions(EXPECTED_EXTENSIONS, _collected({"NNUNet": "unknown"}))
    assert report.rows[0].status == "present_ok"
    assert format_extension_status_row(report.rows[0]) == "✓ NNUNet — installed"


def test_extension_row_wording_keeps_revision_diagnostic_without_an_expectation():
    installed = evaluate_required_extensions(
        EXPECTED_EXTENSIONS, _collected({"NNUNet": "0cb736d"}),
    ).rows[0]
    missing = evaluate_required_extensions(EXPECTED_EXTENSIONS, _collected({"NNUNet": None})).rows[0]
    unavailable = evaluate_required_extensions(
        EXPECTED_EXTENSIONS, _collected({"NNUNet": None}, manager_available=False),
    ).rows[0]

    assert format_extension_status_row(installed) == "✓ NNUNet — installed (revision 0cb736d)"
    assert format_extension_status_row(missing) == "✕ NNUNet — not installed"
    assert format_extension_status_row(unavailable) == "⚠ NNUNet — cannot verify (Extensions Manager unavailable)"


def test_pinned_manifest_version_mismatch_still_renders_defensively():
    report = evaluate_required_extensions(
        [ExpectedExtension("Locally pinned", "0cb736d", ("0cb736d",))],
        _collected({"Locally pinned": "1ab2345"}),
    )
    rendered = format_extension_status_row(report.rows[0])
    assert report.rows[0].status == "version_mismatch"
    assert "installed revision is not accepted" in rendered
    assert "Expected" not in rendered


def test_pinned_manifest_keeps_an_unknown_revision_as_diagnostics():
    report = evaluate_required_extensions(
        [ExpectedExtension("Locally pinned", "0cb736d", ("0cb736d",))],
        _collected({"Locally pinned": "unknown"}),
    )
    assert format_extension_status_row(report.rows[0]) == (
        "✕ Locally pinned — installed revision is not accepted (revision unknown)"
    )
