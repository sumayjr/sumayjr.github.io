import logging

import qt
import slicer
import ctk
from slicer.ScriptedLoadableModule import ScriptedLoadableModule, ScriptedLoadableModuleWidget
from slicer.i18n import tr, translate

from DentoFacLib import (
    DENTAL_SEGMENTATOR_MODEL,
    ModelStore,
    NNUNetDependencyService,
    EXPECTED_EXTENSIONS,
    collect_installed_extension_revisions,
    collect_runtime_status,
    collect_segmentator_readiness,
    evaluate_required_extensions,
    format_extension_status_row,
    ModelDownloadOutcome,
    resolve_model_download_outcome,
)


class DentoFac(ScriptedLoadableModule):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent.title = tr("DentoFac Hub")
        self.parent.categories = [translate("qSlicerAbstractCoreModule", "DentoFac")]
        self.parent.contributors = ["DentoFac contributors"]
        self.parent.helpText = (
            tr("Set up and check the shared DentoFac environment. ")
            + tr("Workflow actions are available in their respective DentoFac modules.")
        )


class DentoFacWidget(ScriptedLoadableModuleWidget):
    def setup(self):
        super().setup()

        content = qt.QWidget()
        layout = qt.QFormLayout(content)
        self.layout.addWidget(content)

        introduction = qt.QLabel(
            tr("DentoFac Hub provides shared setup, readiness checks, model storage, ")
            + tr("and diagnostics. Segmentator execution and clinical controls remain in ")
            + tr("DentoFac Segmentator.")
        )
        introduction.wordWrap = True
        layout.addRow(introduction)

        self.requiredExtensionsPanel = ctk.ctkCollapsibleButton()
        self.requiredExtensionsPanelLayout = qt.QFormLayout(self.requiredExtensionsPanel)
        self.requiredExtensionLabels = {}
        for extension in EXPECTED_EXTENSIONS:
            label = qt.QLabel()
            label.wordWrap = True
            self.requiredExtensionLabels[extension.name] = label
            self.requiredExtensionsPanelLayout.addRow(extension.name + ":", label)
        layout.addRow(self.requiredExtensionsPanel)

        self.pythonVersionLabel = qt.QLabel()
        self.slicerVersionLabel = qt.QLabel()
        self.statusLabel = qt.QLabel()
        self.statusLabel.wordWrap = True
        layout.addRow(tr("Python:"), self.pythonVersionLabel)
        layout.addRow(tr("Slicer:"), self.slicerVersionLabel)
        layout.addRow(tr("Shared environment:"), self.statusLabel)

        self.segmentatorStatusLabel = qt.QLabel()
        self.segmentatorStatusLabel.wordWrap = True
        layout.addRow(tr("DentoFac Segmentator:"), self.segmentatorStatusLabel)

        self.installDependenciesButton = qt.QPushButton(tr("Install NNUNet requirements"))
        self.installDependenciesButton.connect("clicked()", self.installDependencies)
        layout.addRow(self.installDependenciesButton)

        self.downloadModelButton = qt.QPushButton(tr("Download Segmentator model"))
        self.downloadModelButton.connect("clicked()", self.downloadModel)
        layout.addRow(self.downloadModelButton)

        self.modelDownloadStatusLabel = qt.QLabel(
            tr("Ready to check for the Segmentator model.")
        )
        self.modelDownloadStatusLabel.wordWrap = True
        layout.addRow(tr("Model download:"), self.modelDownloadStatusLabel)

        self.importLegacyModelButton = qt.QPushButton(tr("Import validated legacy model…"))
        self.importLegacyModelButton.connect("clicked()", self.importLegacyModel)
        layout.addRow(self.importLegacyModelButton)

        self.refreshButton = qt.QPushButton(tr("Refresh status"))
        self.refreshButton.connect("clicked()", self.refresh)
        layout.addRow(self.refreshButton)
        layout.addRow(qt.QLabel())

        self._modelDownloadInProgress = False
        self._modelDownloadMadeProgress = False
        self.refresh()

    def refresh(self):
        status = collect_runtime_status()
        self.pythonVersionLabel.text = status.python_version
        self.slicerVersionLabel.text = status.slicer_version or tr("unavailable")
        try:
            collected_extensions = collect_installed_extension_revisions(EXPECTED_EXTENSIONS)
            self.refreshRequiredExtensions(collected_extensions)
            readiness = collect_segmentator_readiness(collected_extensions)
        except Exception as error:
            logging.exception("DentoFac Hub readiness collection failed")
            self.statusLabel.text = tr("Shared DentoFac services could not be checked.")
            self.segmentatorStatusLabel.text = tr(
                "⚠ DentoFac Segmentator readiness could not be checked: {error}"
            ).format(error=error)
            self.requiredExtensionsPanel.text = tr("⚠ Required extensions: status unavailable")
            self._setRequiredExtensionsPanelAppearance(False)
            self._setRequiredExtensionsPanelCollapsed(False)
            self.installDependenciesButton.setEnabled(not self._modelDownloadInProgress)
            self.downloadModelButton.setEnabled(False)
            self.importLegacyModelButton.setEnabled(not self._modelDownloadInProgress)
            self.refreshButton.setEnabled(not self._modelDownloadInProgress)
            return
        self.statusLabel.text = tr("Shared DentoFac services are available.")
        self.segmentatorStatusLabel.text = readiness.summary
        self.installDependenciesButton.setEnabled(
            not self._modelDownloadInProgress and readiness.dependency_ready is False
        )
        self.downloadModelButton.setEnabled(
            not self._modelDownloadInProgress and readiness.dependency_ready
        )
        self.importLegacyModelButton.setEnabled(not self._modelDownloadInProgress)
        self.refreshButton.setEnabled(not self._modelDownloadInProgress)

    def refreshRequiredExtensions(self, collected_extensions=None):
        collected_extensions = collected_extensions or collect_installed_extension_revisions(EXPECTED_EXTENSIONS)
        report = evaluate_required_extensions(
            EXPECTED_EXTENSIONS,
            collected_extensions,
        )
        for row in report.rows:
            self.requiredExtensionLabels[row.name].text = format_extension_status_row(row, tr)

        if report.all_ok:
            self.requiredExtensionsPanel.text = tr("✓ Required extensions: all present")
        else:
            self.requiredExtensionsPanel.text = tr("✕ Required extensions: {count} problem(s)").format(
                count=report.problem_count,
            )
        self._setRequiredExtensionsPanelAppearance(report.all_ok)
        self._setRequiredExtensionsPanelCollapsed(report.all_ok)

    def _setRequiredExtensionsPanelCollapsed(self, collapsed):
        setter = getattr(self.requiredExtensionsPanel, "setCollapsed", None)
        if callable(setter):
            setter(collapsed)
        else:
            self.requiredExtensionsPanel.collapsed = collapsed

    def _setRequiredExtensionsPanelAppearance(self, all_ok):
        """Use a theme-relative status tint so both Slicer themes retain contrast."""
        base = self.requiredExtensionsPanel.palette.color(qt.QPalette.Button)
        status = qt.QColor(46, 125, 50) if all_ok else qt.QColor(198, 40, 40)
        # A one-quarter tint preserves the active Slicer light/dark palette while
        # making the collapsible header visibly green or red.
        background = qt.QColor(
            (base.red() * 3 + status.red()) // 4,
            (base.green() * 3 + status.green()) // 4,
            (base.blue() * 3 + status.blue()) // 4,
        )
        self.requiredExtensionsPanel.setStyleSheet(
            "ctkCollapsibleButton { background-color: %s; }" % background.name(),
        )

    def installDependencies(self):
        service = NNUNetDependencyService()
        if not service.status().extension_importable:
            slicer.util.errorDisplay(
                tr("Install the NNUNet extension in Slicer's Extension Manager and restart, then return to DentoFac Hub.")
            )
            self.refresh()
            return
        self.installDependenciesButton.setEnabled(False)
        try:
            if not service.install_python_requirements():
                slicer.util.errorDisplay(tr("NNUNet Python requirement installation did not complete. Check the application log and retry."))
        finally:
            self.refresh()

    def _segmentator_checker(self):
        # The model descriptor/cache is shared; the release format and progress UI
        # remain workflow-specific until another workflow uses the same protocol.
        from DentoFacSegmentatorLib.PythonDependencyChecker import PythonDependencyChecker
        return PythonDependencyChecker(destWeightFolder=ModelStore(DENTAL_SEGMENTATOR_MODEL).model_root)

    def _setModelDownloadStatus(self, message):
        """Keep model-download feedback visible while the synchronous request runs."""
        self.modelDownloadStatusLabel.text = message
        process_events = getattr(slicer.app, "processEvents", None)
        if callable(process_events):
            process_events()

    def _onModelDownloadProgress(self, message):
        self._modelDownloadMadeProgress = True
        self._setModelDownloadStatus(message)

    def downloadModel(self):
        self._modelDownloadInProgress = True
        self.downloadModelButton.setEnabled(False)
        self.downloadModelButton.setText(tr("Downloading Segmentator model…"))
        self._modelDownloadMadeProgress = False
        self.installDependenciesButton.setEnabled(False)
        self.importLegacyModelButton.setEnabled(False)
        self.refreshButton.setEnabled(False)
        self._setModelDownloadStatus(tr("Checking the model cache and latest release…"))
        try:
            downloaded = self._segmentator_checker().downloadWeightsIfNeeded(self._onModelDownloadProgress)
            outcome = resolve_model_download_outcome(
                downloaded,
                self._modelDownloadMadeProgress,
            )
            if outcome is ModelDownloadOutcome.INSTALLED:
                self._setModelDownloadStatus(tr("Model download complete. Checking readiness…"))
            elif outcome is ModelDownloadOutcome.KEPT_EXISTING:
                self._setModelDownloadStatus(
                    tr("Model download did not run; existing model files were kept.")
                )
            else:
                self._setModelDownloadStatus(
                    tr("Model download failed. See the error dialog and application log.")
                )
        except Exception:
            logging.exception("DentoFac Hub model download failed unexpectedly")
            self._setModelDownloadStatus(
                tr("Model download failed. See the error dialog and application log.")
            )
            slicer.util.errorDisplay(
                tr("The Segmentator model download failed unexpectedly. Check the application log and retry.")
            )
        finally:
            self._modelDownloadInProgress = False
            self.downloadModelButton.setText(tr("Download Segmentator model"))
            self.refresh()

    def importLegacyModel(self):
        from DentoFacSegmentatorLib.ModelPath import legacyModelRoot
        store = ModelStore(DENTAL_SEGMENTATOR_MODEL)
        legacy = legacyModelRoot()
        if not legacy.exists():
            slicer.util.infoDisplay(tr("No legacy Segmentator model cache was found."))
            return
        confirmed = qt.QMessageBox.question(
            self, tr("Import legacy model"),
            tr("Copy the validated legacy model from:\n{legacy}\n\nto DentoFac's private cache:\n{destination}\n\nThe original will not be changed.").format(
                legacy=legacy, destination=store.model_root
            ),
        ) == qt.QMessageBox.Yes
        if not confirmed:
            return
        from DentoFacLib.Models import validate_model
        if not store.copy_validated_legacy(legacy, lambda *_: True, validate_model):
            slicer.util.errorDisplay(tr("The legacy model was invalid, the DentoFac cache already exists, or the copy could not be completed."))
        self.refresh()
