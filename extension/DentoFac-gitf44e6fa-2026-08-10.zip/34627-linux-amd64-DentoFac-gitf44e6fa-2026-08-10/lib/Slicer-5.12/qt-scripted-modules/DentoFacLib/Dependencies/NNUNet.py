"""NNUNet extension/Python dependency readiness, shared by DentoFac workflows."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class DependencyStatus:
    """Import and Python-requirement capability of the NNUNet runtime."""

    extension_importable: bool
    python_requirements_installed: bool
    extension_capable: bool = True

    @property
    def ready(self) -> bool:
        return (
            self.extension_importable
            and self.python_requirements_installed
            and self.extension_capable
        )


class NNUNetDependencyService:
    def status(self) -> DependencyStatus:
        try:
            import SlicerNNUNetLib  # noqa: F401
            extension_importable = True
        except (ImportError, AttributeError, RuntimeError, TypeError):
            extension_importable = False
        try:
            from SlicerNNUNetLib import Parameter, SegmentationLogic

            extension_capable = callable(getattr(Parameter, "isValid", None)) and all(
                callable(getattr(SegmentationLogic, name, None))
                for name in ("setParameter", "startSegmentation", "loadSegmentation")
            )
        except (ImportError, AttributeError, RuntimeError, TypeError):
            extension_capable = False
        try:
            import torch  # noqa: F401
            import nnunetv2  # noqa: F401
            requirements_installed = True
        except ImportError:
            requirements_installed = False
        return DependencyStatus(extension_importable, requirements_installed, extension_capable)

    def install_python_requirements(self, progress_callback=None) -> bool:
        """Perform the explicit, user-initiated NNUNet Python setup."""
        try:
            from SlicerNNUNetLib import InstallLogic
        except ImportError:
            return False
        logic = InstallLogic()
        if progress_callback is not None:
            logic.progressInfo.connect(progress_callback)
        return bool(logic.setupPythonRequirements())
