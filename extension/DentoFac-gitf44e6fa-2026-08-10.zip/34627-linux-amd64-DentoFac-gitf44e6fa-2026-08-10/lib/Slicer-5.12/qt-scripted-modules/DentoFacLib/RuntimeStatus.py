"""Small, read-only runtime facts used by the initial DentoFac Hub."""

from dataclasses import dataclass
import sys
from typing import Optional

from .Dependencies import NNUNetDependencyService
from .ExtensionStatus import CollectedExtensions, collect_installed_extension_revisions
from .Models import DENTAL_SEGMENTATOR_MODEL, ModelStore, validate_model


@dataclass(frozen=True)
class RuntimeStatus:
    python_version: str
    slicer_version: Optional[str]


@dataclass(frozen=True)
class WorkflowReadiness:
    """Small shared readiness contract consumed by the Hub and workflows."""
    dependency_ready: bool
    model_ready: bool
    model_authoritative: bool
    summary: str
    manager_available: bool = True
    extension_installed: Optional[bool] = None


def collect_runtime_status() -> RuntimeStatus:
    slicer_version = None
    try:
        import slicer

        slicer_version = getattr(slicer.app, "applicationVersion", None)
    except (ImportError, AttributeError):
        pass

    return RuntimeStatus(
        python_version=sys.version.split()[0],
        slicer_version=slicer_version,
    )


def collect_segmentator_readiness(
    collected_extensions: Optional[CollectedExtensions] = None,
) -> WorkflowReadiness:
    """Collect Segmentator capability using the shared extension query.

    The Extensions Manager describes installation; importing SlicerNNUNetLib
    describes whether the installed extension can actually be used.
    """
    collected_extensions = collected_extensions or collect_installed_extension_revisions()
    dependencies = NNUNetDependencyService().status()
    validation_error = None
    try:
        validation = validate_model(ModelStore(DENTAL_SEGMENTATOR_MODEL).model_root)
    except (AttributeError, RuntimeError, TypeError) as error:
        validation = None
        validation_error = error
    model_ready = validation is not None and validation.isValid and validation.authoritative
    model_authoritative = validation is not None and validation.authoritative
    extension_installed = collected_extensions.revisions.get("NNUNet") is not None
    if not collected_extensions.manager_available:
        summary = "NNUNet availability cannot be verified because the Extensions Manager is unavailable."
    elif not extension_installed:
        summary = "NNUNet extension is not installed."
    elif validation_error is not None or not dependencies.extension_importable or not dependencies.extension_capable:
        summary = "NNUNet is installed but could not be loaded. Restart Slicer and check that the extension is enabled."
    elif not dependencies.python_requirements_installed:
        summary = "NNUNet Python requirements are not installed."
    elif not model_authoritative:
        summary = "Model cache cannot be verified until NNUNet is available."
    elif not model_ready:
        summary = "Segmentator model is not installed or is invalid."
    else:
        summary = "DentoFac Segmentator is ready."
    return WorkflowReadiness(
        dependencies.ready and collected_extensions.manager_available and extension_installed and validation_error is None,
        model_ready,
        model_authoritative,
        summary,
        collected_extensions.manager_available,
        extension_installed if collected_extensions.manager_available else None,
    )
