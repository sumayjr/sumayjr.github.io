"""Required Slicer extension manifest and status evaluation for the DentoFac Hub."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Optional, Sequence


@dataclass(frozen=True)
class ExpectedExtension:
    """One extension required by a DentoFac workflow.

    ``require_accepted_revision=False`` is the deliberate per-extension
    present-only gate.  Set it to ``True`` only when a workflow has a genuine
    fixed-revision contract; Slicer extension revisions are Git SHAs, not
    semver values that can safely be ordered.
    """

    name: str
    validated_revision: str
    accepted_scmrevisions: Sequence[str]
    require_accepted_revision: bool = True


# The manifest is intentionally owned here rather than by the Hub UI.  Adding a
# future workflow extension is a declarative change to this list.
# NNUNet is gated present-only.  Its validated revision remains evidence for the
# documented baseline, not a requirement imposed by the Hub panel.
EXPECTED_EXTENSIONS = [
    ExpectedExtension(
        name="NNUNet",
        validated_revision="0cb736d",
        accepted_scmrevisions=("0cb736d",),
        require_accepted_revision=False,
    ),
]


MINIMUM_GIT_SHA_PREFIX_LENGTH = 7
UNKNOWN_REVISION = "unknown"


@dataclass(frozen=True)
class ExtensionStatusRow:
    name: str
    detected_version: Optional[str]
    status: str  # present_ok, version_mismatch, manager_unavailable, or missing


@dataclass(frozen=True)
class CollectedExtensions:
    """Required-extension metadata and Extensions Manager availability."""

    manager_available: bool
    revisions: dict[str, Optional[str]]


@dataclass(frozen=True)
class ExtensionStatusReport:
    rows: tuple[ExtensionStatusRow, ...]
    all_ok: bool

    @property
    def problem_count(self) -> int:
        return sum(row.status != "present_ok" for row in self.rows)


def _revisions_match(detected_revision: str, accepted_revision: str) -> bool:
    """Return whether two short or full Git SHAs identify the same revision."""
    detected = detected_revision.strip().lower()
    accepted = accepted_revision.strip().lower()
    if not detected or not accepted:
        return False
    if not all(character in "0123456789abcdef" for character in detected + accepted):
        return False
    shorter, longer = sorted((detected, accepted), key=len)
    return len(shorter) >= MINIMUM_GIT_SHA_PREFIX_LENGTH and longer.startswith(shorter)


def evaluate_required_extensions(
    manifest: Iterable[ExpectedExtension], collected: CollectedExtensions,
) -> ExtensionStatusReport:
    """Evaluate extension metadata without importing Qt or Slicer.

    ``collected`` distinguishes an unavailable Extensions Manager from an absent
    extension.  Its revisions map contains an installed extension's reported
    revision, while ``None`` means the manager reports the extension absent.
    This narrow contract keeps the gate independently unit-testable in a plain
    Python process.
    """

    rows = []
    for expected in manifest:
        detected = collected.revisions.get(expected.name)
        if not collected.manager_available:
            status = "manager_unavailable"
        elif detected is None:
            status = "missing"
        elif not expected.require_accepted_revision or any(
            _revisions_match(detected, accepted) for accepted in expected.accepted_scmrevisions
        ):
            status = "present_ok"
        else:
            status = "version_mismatch"
        rows.append(ExtensionStatusRow(expected.name, detected, status))
    return ExtensionStatusReport(tuple(rows), all(row.status == "present_ok" for row in rows))


def collect_installed_extension_revisions(
    manifest: Iterable[ExpectedExtension] = EXPECTED_EXTENSIONS,
) -> CollectedExtensions:
    """Read required extension revisions from Slicer's extensions manager.

    The manager API has changed across Slicer releases, so every access is
    guarded.  Manager availability is returned separately so the Hub never
    mistakes an unavailable manager for a missing extension.
    """

    entries = tuple(manifest)
    detected = {entry.name: None for entry in entries}
    try:
        import slicer

        manager_factory = getattr(getattr(slicer, "app", None), "extensionsManagerModel", None)
        manager = manager_factory() if callable(manager_factory) else manager_factory
        if manager is None:
            return CollectedExtensions(False, detected)

        installed_extensions = getattr(manager, "installedExtensions", ())
        installed_extensions = installed_extensions() if callable(installed_extensions) else installed_extensions
        installed_names = set(installed_extensions or ())
        is_installed = getattr(manager, "isExtensionInstalled", None)
        metadata_for = getattr(manager, "extensionMetadata", None)

        for entry in entries:
            try:
                installed = bool(is_installed(entry.name)) if callable(is_installed) else entry.name in installed_names
                if not installed:
                    continue
                metadata = metadata_for(entry.name) if callable(metadata_for) else {}
                # Slicer's extensionMetadata() exposes the installed revision under
                # the "revision" key; "scmrevision" only appears in the extension
                # description file, not this map.  Read "revision" first and keep
                # "scmrevision" as a cross-version fallback.
                revision = None
                if hasattr(metadata, "get"):
                    revision = metadata.get("revision") or metadata.get("scmrevision")
                # An installed extension without metadata is a version mismatch,
                # not a false "not installed" result.
                detected[entry.name] = revision or UNKNOWN_REVISION
            except (AttributeError, RuntimeError, TypeError):
                continue
    except (ImportError, AttributeError, RuntimeError, TypeError):
        return CollectedExtensions(False, detected)
    return CollectedExtensions(True, detected)


def format_extension_status_row(row: ExtensionStatusRow, translate=lambda text: text) -> str:
    """Render one required-extension row without coupling it to Qt widgets."""
    status_text = {
        "present_ok": translate("installed"),
        "version_mismatch": translate("installed revision is not accepted"),
        "manager_unavailable": translate("cannot verify"),
        "missing": translate("not installed"),
    }.get(row.status, translate("unknown"))
    if row.status == "manager_unavailable":
        return translate("⚠ {name} — {status} (Extensions Manager unavailable)").format(
            name=row.name, status=status_text,
        )
    if row.status == "present_ok" and row.detected_version and row.detected_version != UNKNOWN_REVISION:
        return translate("✓ {name} — {status} (revision {revision})").format(
            name=row.name, status=status_text, revision=row.detected_version,
        )
    marker = "✓" if row.status == "present_ok" else "✕"
    if row.status == "version_mismatch" and row.detected_version:
        # Pinned manifests retain an unreadable revision as useful diagnostics.
        return translate("{marker} {name} — {status} (revision {revision})").format(
            marker=marker, name=row.name, status=status_text, revision=row.detected_version,
        )
    return translate("{marker} {name} — {status}").format(
        marker=marker, name=row.name, status=status_text,
    )
