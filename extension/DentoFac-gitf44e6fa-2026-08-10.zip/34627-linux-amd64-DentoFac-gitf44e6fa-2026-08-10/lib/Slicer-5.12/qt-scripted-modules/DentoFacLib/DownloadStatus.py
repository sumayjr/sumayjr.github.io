"""Pure outcome selection for a Segmentator model-download attempt."""

from enum import Enum


class ModelDownloadOutcome(Enum):
    FAILED = "failed"
    INSTALLED = "installed"
    KEPT_EXISTING = "kept-existing"


def resolve_model_download_outcome(
    download_succeeded: bool,
    made_progress: bool,
) -> ModelDownloadOutcome:
    """Classify the downloader's ambiguous success result for the Hub UI.

    ``downloadWeightsIfNeeded`` returns ``True`` both after a real download and
    when it keeps the existing files. The progress callback is invoked only for
    the real download path, so it is the reliable distinction.
    """
    if not download_succeeded:
        return ModelDownloadOutcome.FAILED
    if made_progress:
        return ModelDownloadOutcome.INSTALLED
    return ModelDownloadOutcome.KEPT_EXISTING
